import { API } from '../config/constants';
import api from '../api/request';

export class ToDoListService {
  static async getTasks() {
    return await api.get(API.TO_DO_LIST.DEFAULT)
      .then((res) => {
        console.log("Hello")
        return Promise.resolve(res.data)
      })
      .catch((e) => {
        return Promise.reject(e?.response?.data);
      })
  }
}

