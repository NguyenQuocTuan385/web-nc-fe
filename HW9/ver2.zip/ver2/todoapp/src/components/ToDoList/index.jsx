import "./styles.css"
import AddTasks from './AddTask';
import ShowTasks from './ShowTasks';
import FilterTasks from './FilterTasks';
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { setTasks } from "../../redux/reducers/Task/actionTypes";
import { ToDoListService } from "../../api/todolist"

const ToDoList = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    const getTasks = async () => {
      ToDoListService.getTasks()
        .then(res => {
          dispatch(setTasks(res.data))
          console.log(res);
        })
        .catch((e) => {
          console.log(e)
        })
    }
    getTasks();
  }, [])

  return (
    <>
      <h1>Danh sách công việc</h1>
      <div className="handleTask">
        <FilterTasks />
        <AddTasks />
      </div>
      <ShowTasks />
    </>
  );
}

export default ToDoList;