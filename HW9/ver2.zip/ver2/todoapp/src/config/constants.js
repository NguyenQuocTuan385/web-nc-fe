
export const API = {
  TO_DO_LIST: {
    DEFAULT: "/api/tasks",
    UPDATE: "/api/tasks/:id"
  }
}